import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/health/domain/dashboard_helpers.dart';
import '../../../core/providers/health_state_provider.dart';
import '../../../core/providers/metabolic_hub_provider.dart';
import '../../fasting/application/fasting_controller.dart';
import '../../profile/application/user_controller.dart';
import '../../training/application/training_controller.dart';
import '../../training/domain/training_enums.dart';
import '../data/telemetry_repository.dart';
import '../domain/telemetry_data.dart';

// ─────────────────────────────────────────────────────────────────────────────
// ELENA TODAY — Aggregated Dashboard State
// ─────────────────────────────────────────────────────────────────────────────

/// Immutable snapshot consumed by TodayDashboardScreen.
class ElenaTodayState {
  final DashboardScoreResult score;
  final FastingWindowState fastingWindow;
  final String suggestion;

  // Raw pillar scores (0-100) for the metric ring.
  final double hydrationScore;
  final double nutritionScore;
  final double sleepScore;
  final double trainingScore;
  final double fastingScore;

  // Exercise session info.
  final int exerciseActiveMinutes;
  final bool isTrainingActive;
  final String exerciseCategoryLabel;

  // Display-ready values (real units, not percentages).
  final double hydrationLiters;
  final double hydrationGoalLiters;
  final double sleepHours;
  final double nutritionKcal;
  final String userName;

  // Telemetry data (real-time from Firestore).
  final TelemetryData? telemetry;

  // Contextual suggestions from metamorfosis_posts.
  final List<MetamorfosisPost> contextSuggestions;

  const ElenaTodayState({
    required this.score,
    required this.fastingWindow,
    required this.suggestion,
    required this.hydrationScore,
    required this.nutritionScore,
    required this.sleepScore,
    required this.trainingScore,
    required this.fastingScore,
    required this.exerciseActiveMinutes,
    required this.isTrainingActive,
    required this.exerciseCategoryLabel,
    required this.hydrationLiters,
    required this.hydrationGoalLiters,
    required this.sleepHours,
    required this.nutritionKcal,
    required this.userName,
    this.telemetry,
    this.contextSuggestions = const [],
  });
}

/// Single provider that aggregates all pillars into [ElenaTodayState].
/// Never throws — every branch has a safe fallback.
///
/// Now integrates real-time [TelemetryData] from Firestore streams
/// and [MetamorfosisPost] suggestions from the content collection.
final elenaTodayProvider = Provider<ElenaTodayState>((ref) {
  // ── Telemetry (real-time Firestore) ───────────────────────────────────
  final telemetryAsync = ref.watch(telemetryStreamProvider);
  final telemetry = telemetryAsync.valueOrNull;

  // ── Suggestions (metamorfosis_posts) ──────────────────────────────────
  final suggestionsAsync = ref.watch(suggestionsStreamProvider);
  final contextSuggestions = suggestionsAsync.valueOrNull ?? [];

  // ── HealthState (centralized scores) ──────────────────────────────────
  final hs = ref.watch(healthStateProvider);

  // ── MetabolicHub (display-ready real values, fallback) ────────────────
  final hub = ref.watch(metabolicHubProvider);

  // ── User ──────────────────────────────────────────────────────────────
  final user = ref.watch(currentUserStreamProvider).valueOrNull;
  final firstName = (user?.name ?? '').split(' ').first;
  final hydrationGoalGlasses = (user?.currentWeightKg ?? 65.0) / 7;

  // ── Fasting ───────────────────────────────────────────────────────────
  final fastingAsync = ref.watch(fastingControllerProvider);
  final fasting = fastingAsync.valueOrNull ?? FastingState.initial();

  final fastingWindow = getFastingWindowState(
    isFasting: fasting.isFasting,
    elapsed: fasting.elapsed,
    plannedHours: fasting.plannedHours,
  );

  // ── Training ──────────────────────────────────────────────────────────
  final training = ref.watch(trainingControllerProvider);
  final isTrainingActive = training.phase == TrainingSessionStep.active;
  final exerciseMinutes = telemetry != null
      ? telemetry.exerciseMinutes
      : (training.elapsedSeconds / 60).ceil();

  // ── Pillar scores (prefer Telemetry → HealthState → zero) ─────────────
  final trainingScore =
      hs.trainingScore > 0 ? hs.trainingScore : training.rpe * 10.0;
  final sleepScore = hs.sleepScore;
  final nutritionScore = hs.nutritionScore;
  final hydrationScore = telemetry != null && telemetry.hydrationGoalGlasses > 0
      ? (telemetry.hydrationGlasses / telemetry.hydrationGoalGlasses * 100)
          .clamp(0.0, 100.0)
      : hs.hydrationScore;
  final fastingScore =
      hs.fastingScore > 0 ? hs.fastingScore : fasting.fastingPercent;

  // ── Score ─────────────────────────────────────────────────────────────
  final score = computeDashboardScore(
    trainingScore: trainingScore,
    sleepScore: sleepScore,
    nutritionScore: nutritionScore,
    hydrationScore: hydrationScore,
    fastingScore: fastingScore,
  );

  // ── Suggestion (prefer metamorfosis_posts → fallback to heuristic) ────
  final isFastingProlonged =
      fasting.isFasting && fasting.elapsed.inHours >= 16;
  final heuristicSuggestion = generateDailySuggestion(
    sleepScore: sleepScore,
    hydrationScore: hydrationScore,
    isFastingProlonged: isFastingProlonged,
    isTrainingActive: isTrainingActive,
  );
  final suggestion = contextSuggestions.isNotEmpty
      ? contextSuggestions.first.body
      : heuristicSuggestion;

  // ── Display-ready values (prefer Telemetry → MetabolicHub fallback) ───
  final displayHydrationLiters =
      telemetry?.hydrationLiters ?? (hub.hydrationLevel * 0.25);
  final displayHydrationGoalLiters =
      telemetry?.hydrationGoalLiters ?? (hydrationGoalGlasses * 0.25);
  final displaySleepHours =
      telemetry?.sleepHours ?? (hub.sleepMinutes / 60.0);
  final displayNutritionKcal =
      telemetry?.nutritionKcal.toDouble() ?? hub.nutritionScore;

  return ElenaTodayState(
    score: score,
    fastingWindow: fastingWindow,
    suggestion: suggestion,
    hydrationScore: hydrationScore,
    nutritionScore: nutritionScore,
    sleepScore: sleepScore,
    trainingScore: trainingScore,
    fastingScore: fastingScore,
    exerciseActiveMinutes: exerciseMinutes,
    isTrainingActive: isTrainingActive,
    exerciseCategoryLabel: training.category.title,
    hydrationLiters: displayHydrationLiters,
    hydrationGoalLiters: displayHydrationGoalLiters,
    sleepHours: displaySleepHours,
    nutritionKcal: displayNutritionKcal,
    userName: firstName.isNotEmpty ? firstName : 'tú',
    telemetry: telemetry,
    contextSuggestions: contextSuggestions,
  );
});

/// Convenience provider that exposes the loading state of the telemetry stream.
/// Used by the Dashboard to show "SYNCHRONIZING..." states.
final telemetryLoadingProvider = Provider.autoDispose<bool>((ref) {
  return ref.watch(telemetryStreamProvider).isLoading;
});

/// Convenience provider that exposes error state.
/// Used by the Dashboard to show "SIGNAL LOST" states.
final telemetryErrorProvider = Provider.autoDispose<Object?>((ref) {
  return ref.watch(telemetryStreamProvider).error;
});
