import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../../core/health/domain/dashboard_helpers.dart';
import '../../../core/providers/circadian_phase_provider.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/widgets/blueprint_grid.dart';
import '../../fasting/application/fasting_controller.dart';
import '../../profile/application/user_controller.dart';
import '../application/elena_today_provider.dart';
import '../data/telemetry_repository.dart';

// ─────────────────────────────────────────────────────────────────────────────
// TODAY DASHBOARD — ELENA SYSTEM
// ─────────────────────────────────────────────────────────────────────────────
// Primary dashboard screen. Mounted at '/' (tab HOY).
// Replaces the legacy pentagon-based DashboardScreen.
//
// Real-time: reads TelemetryData + MetamorfosisPost streams via providers.
// States:  loading → "SYNCHRONIZING…" | error → "SIGNAL LOST" | data → full UI.
// ─────────────────────────────────────────────────────────────────────────────

class TodayDashboardScreen extends ConsumerWidget {
  const TodayDashboardScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(elenaTodayProvider);
    final circadianLabel = ref.watch(circadianWindowLabelProvider);
    final isLoading = ref.watch(telemetryLoadingProvider);
    final telemetryError = ref.watch(telemetryErrorProvider);

    return Scaffold(
      backgroundColor: Colors.transparent,
      body: BlueprintGrid(
        child: SafeArea(
          child: CustomScrollView(
            physics: const BouncingScrollPhysics(),
            slivers: [
              SliverToBoxAdapter(
                child: Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // ─── 1. HEADER ────────────────────────────────
                      _ElenaSystemHeader(
                        userName: state.userName,
                        isLoading: isLoading,
                        hasError: telemetryError != null,
                      ),

                      const SizedBox(height: 24),

                      // ─── SIGNAL LOST — error state ────────────────
                      if (telemetryError != null) ...[
                        _SignalLostBanner(
                          onRetry: () =>
                              ref.invalidate(telemetryStreamProvider),
                        ),
                        const SizedBox(height: 16),
                      ],

                      // ─── 2. CIRCADIAN BAR ─────────────────────────
                      _CircadianSection(label: circadianLabel),

                      const SizedBox(height: 16),

                      // ─── 3. FASTING STATUS ────────────────────────
                      _FastingStatusCard(window: state.fastingWindow),

                      const SizedBox(height: 16),

                      // ─── 4. SUGGESTION ────────────────────────────
                      _SuggestionCard(text: state.suggestion),

                      const SizedBox(height: 32),

                      // ─── 5. RADIAL SCORE + ORBITAL METRICS ────────
                      Center(
                        child: _OrbitalScoreSection(state: state),
                      ),

                      const SizedBox(height: 32),

                      // ─── 6. PANIC BUTTON ──────────────────────────
                      _HungerPanicCard(ref: ref),

                      const SizedBox(height: 32),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// 1. HEADER — (•·•) ELENA_SYSTEM [TELEMETRÍA]  +  Hola, {name}.
// ═══════════════════════════════════════════════════════════════════════════════

class _ElenaSystemHeader extends StatelessWidget {
  final String userName;
  final bool isLoading;
  final bool hasError;
  const _ElenaSystemHeader({
    required this.userName,
    this.isLoading = false,
    this.hasError = false,
  });

  @override
  Widget build(BuildContext context) {
    // Badge label reflects telemetry state.
    final String badgeLabel;
    final Color badgeColor;
    if (hasError) {
      badgeLabel = 'SIGNAL LOST';
      badgeColor = Colors.redAccent;
    } else if (isLoading) {
      badgeLabel = 'SYNCING…';
      badgeColor = const Color(0xFFBF8B2E);
    } else {
      badgeLabel = 'TELEMETRÍA';
      badgeColor = AppTheme.primary;
    }

    // Sub-label
    final String subLabel;
    if (hasError) {
      subLabel = 'RECONECTANDO…';
    } else if (isLoading) {
      subLabel = 'SYNCHRONIZING…';
    } else {
      subLabel = 'SISTEMAS EN LÍNEA';
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Top row: logo + telemetry badge + settings
        Row(
          children: [
            Text(
              '(•·•)',
              style: GoogleFonts.jetBrainsMono(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: AppTheme.primary,
              ),
            ),
            const SizedBox(width: 10),
            Text(
              'ELENA_SYSTEM',
              style: GoogleFonts.jetBrainsMono(
                fontSize: 20,
                fontWeight: FontWeight.w900,
                color: AppTheme.primary,
                letterSpacing: 2,
              ),
            ),
            const SizedBox(width: 10),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(
                border: Border.all(color: badgeColor, width: 1),
                borderRadius: BorderRadius.circular(4),
              ),
              child: Text(
                badgeLabel,
                style: GoogleFonts.jetBrainsMono(
                  fontSize: 8,
                  fontWeight: FontWeight.bold,
                  color: badgeColor,
                  letterSpacing: 1,
                ),
              ),
            ),
            const Spacer(),
            const Icon(Icons.settings_outlined,
                color: AppTheme.primary, size: 22),
          ],
        ),
        const SizedBox(height: 20),
        // Greeting
        Text(
          'Hola, $userName.',
          style: GoogleFonts.publicSans(
            fontSize: 28,
            fontWeight: FontWeight.w800,
            color: Colors.white,
          ),
        ),
        const SizedBox(height: 2),
        Text(
          subLabel,
          style: GoogleFonts.jetBrainsMono(
            fontSize: 12,
            color: hasError
                ? Colors.redAccent.withValues(alpha: 0.6)
                : Colors.white.withValues(alpha: 0.4),
            letterSpacing: 2,
          ),
        ),
      ],
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// SIGNAL LOST BANNER — console-style error state
// ═══════════════════════════════════════════════════════════════════════════════

class _SignalLostBanner extends StatelessWidget {
  final VoidCallback onRetry;
  const _SignalLostBanner({required this.onRetry});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: BoxDecoration(
        color: Colors.redAccent.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(8),
        border:
            Border.all(color: Colors.redAccent.withValues(alpha: 0.3), width: 1),
      ),
      child: Row(
        children: [
          Icon(Icons.error_outline_rounded,
              color: Colors.redAccent.withValues(alpha: 0.7), size: 20),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'SIGNAL LOST — TELEMETRY OFFLINE',
                  style: GoogleFonts.jetBrainsMono(
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                    color: Colors.redAccent,
                    letterSpacing: 1,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  'Usando datos locales. Reconexión automática.',
                  style: GoogleFonts.jetBrainsMono(
                    fontSize: 9,
                    color: Colors.white.withValues(alpha: 0.4),
                  ),
                ),
              ],
            ),
          ),
          GestureDetector(
            onTap: onRetry,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(
                border: Border.all(
                    color: Colors.redAccent.withValues(alpha: 0.4), width: 1),
                borderRadius: BorderRadius.circular(4),
              ),
              child: Text(
                'RETRY',
                style: GoogleFonts.jetBrainsMono(
                  fontSize: 9,
                  fontWeight: FontWeight.bold,
                  color: Colors.redAccent,
                  letterSpacing: 1,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// 2. CIRCADIAN SECTION — segmented bar with current time
// ═══════════════════════════════════════════════════════════════════════════════

class _CircadianSection extends StatelessWidget {
  final String label;
  const _CircadianSection({required this.label});

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final timeStr =
        '${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}H';
    final dayProgress = (now.hour * 60 + now.minute) / 1440.0;

    // Determine active segment based on hour
    final int activeSegment;
    if (now.hour >= 22 || now.hour < 6) {
      activeSegment = 0; // Sueño
    } else if (now.hour >= 6 && now.hour < 12) {
      activeSegment = 1; // Ayuno
    } else if (now.hour >= 12 && now.hour < 20) {
      activeSegment = 2; // Alimentación
    } else {
      activeSegment = 3; // Ayuno (pre-sleep)
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Title row
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'ESTADO CIRCADIANO',
              style: GoogleFonts.jetBrainsMono(
                fontSize: 12,
                fontWeight: FontWeight.bold,
                color: Colors.white.withValues(alpha: 0.5),
                letterSpacing: 2,
              ),
            ),
            Text(
              timeStr,
              style: GoogleFonts.jetBrainsMono(
                fontSize: 14,
                fontWeight: FontWeight.bold,
                color: AppTheme.primary,
                letterSpacing: 1,
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        // Segmented bar
        LayoutBuilder(
          builder: (context, constraints) {
            final barWidth = constraints.maxWidth;
            return ClipRRect(
              borderRadius: BorderRadius.circular(4),
              child: SizedBox(
                height: 14,
                child: Stack(
                  children: [
                    Row(
                      children: [
                        // Sueño: 22:00-06:00 = 8h/24 ≈ 25%
                        Expanded(
                          flex: 25,
                          child: Container(color: const Color(0xFF1565C0)),
                        ),
                        // Ayuno: 06:00-12:00 = 6h/24 ≈ 25%
                        Expanded(
                          flex: 25,
                          child: Container(color: const Color(0xFFE65100)),
                        ),
                        // Alimentación: 12:00-20:00 = 8h/24 ≈ 33%
                        Expanded(
                          flex: 33,
                          child: Container(color: AppTheme.primary),
                        ),
                        // Ayuno (pre-sleep): 20:00-22:00 ≈ 17%
                        Expanded(
                          flex: 17,
                          child: Container(color: const Color(0xFFBF8B2E)),
                        ),
                      ],
                    ),
                    // Current-time marker
                    Positioned(
                      left: (barWidth * dayProgress).clamp(4.0, barWidth - 4.0),
                      top: 0,
                      bottom: 0,
                      child: Column(
                        children: [
                          Container(
                            width: 8,
                            height: 8,
                            decoration: BoxDecoration(
                              color: AppTheme.primary,
                              shape: BoxShape.circle,
                              border:
                                  Border.all(color: Colors.black, width: 1.5),
                            ),
                          ),
                          Expanded(
                            child:
                                Container(width: 2, color: AppTheme.primary),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            );
          },
        ),
        const SizedBox(height: 8),
        // Labels row
        Row(
          children: [
            _SegmentLabel(text: 'SUEÑO', active: activeSegment == 0),
            const Spacer(),
            _SegmentLabel(text: 'AYUNO', active: activeSegment == 1),
            const Spacer(),
            _SegmentLabel(
              text: 'ALIMENTACIÓN',
              active: activeSegment == 2,
              highlight: true,
            ),
            const Spacer(),
            _SegmentLabel(text: 'AYUNO', active: activeSegment == 3),
          ],
        ),
      ],
    );
  }
}

class _SegmentLabel extends StatelessWidget {
  final String text;
  final bool active;
  final bool highlight;
  const _SegmentLabel({
    required this.text,
    this.active = false,
    this.highlight = false,
  });

  @override
  Widget build(BuildContext context) {
    final color = active && highlight
        ? AppTheme.primary
        : active
            ? Colors.white.withValues(alpha: 0.7)
            : Colors.white.withValues(alpha: 0.3);
    return Text(
      text,
      style: GoogleFonts.jetBrainsMono(
        fontSize: 9,
        fontWeight: active ? FontWeight.bold : FontWeight.normal,
        color: color,
        letterSpacing: 1,
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// 3. FASTING STATUS CARD — green left accent border
// ═══════════════════════════════════════════════════════════════════════════════

class _FastingStatusCard extends StatelessWidget {
  final FastingWindowState window;
  const _FastingStatusCard({required this.window});

  @override
  Widget build(BuildContext context) {
    final isFasting = window.state == 'fasting';
    final elapsedH = window.elapsed.inHours;
    final elapsedM = window.elapsed.inMinutes % 60;
    final nextH = window.nextMilestone.inHours;
    final nextM = window.nextMilestone.inMinutes % 60;

    final stateLabel = isFasting ? 'VENTANA DE AYUNO' : 'VENTANA ALIMENTARIA';
    final nextLabel = isFasting ? 'VENTANA ALIMENTARIA' : 'CIERRE DE VENTANA';

    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF111111),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.white.withValues(alpha: 0.04)),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(8),
        child: Stack(
          children: [
            // Left Accent Bar - Using Positioned to match content height without IntrinsicHeight bugs
            Positioned(
              left: 0,
              top: 0,
              bottom: 0,
              child: Container(
                width: 3,
                color: AppTheme.primary,
              ),
            ),
            // Content Container
            Padding(
              padding: const EdgeInsets.fromLTRB(19, 14, 16, 14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  RichText(
                      text: TextSpan(
                        style: GoogleFonts.jetBrainsMono(
                          fontSize: 12,
                          color: Colors.white.withValues(alpha: 0.6),
                          letterSpacing: 1,
                        ),
                        children: [
                          const TextSpan(text: 'ESTADO: '),
                          TextSpan(
                            text: stateLabel,
                            style: const TextStyle(color: AppTheme.primary),
                          ),
                          TextSpan(
                            text:
                                ' · ${elapsedH.toString().padLeft(2, '0')}H ${elapsedM.toString().padLeft(2, '0')}M',
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      'PRÓXIMO HITO: $nextLabel EN ${nextH.toString().padLeft(2, '0')}H ${nextM.toString().padLeft(2, '0')}M',
                      style: GoogleFonts.jetBrainsMono(
                        fontSize: 10,
                        color: Colors.white.withValues(alpha: 0.3),
                        letterSpacing: 0.5,
                      ),
                    ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// 4. SUGGESTION CARD — amber left accent border
// ═══════════════════════════════════════════════════════════════════════════════

class _SuggestionCard extends StatelessWidget {
  final String text;
  const _SuggestionCard({required this.text});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF111111),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.white.withValues(alpha: 0.04)),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(8),
        child: Stack(
          children: [
            // Left Accent Bar - Using Positioned to match content height without IntrinsicHeight bugs
            Positioned(
              left: 0,
              top: 0,
              bottom: 0,
              child: Container(
                width: 3,
                color: const Color(0xFFBF8B2E),
              ),
            ),
            // Content Container
            Padding(
              padding: const EdgeInsets.fromLTRB(19, 14, 16, 14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                      'SUGERENCIAS DE HOY',
                      style: GoogleFonts.jetBrainsMono(
                        fontSize: 11,
                        fontWeight: FontWeight.bold,
                        color: Colors.white.withValues(alpha: 0.5),
                        letterSpacing: 2,
                      ),
                    ),
                    const SizedBox(height: 10),
                    Text(
                      text,
                      style: GoogleFonts.jetBrainsMono(
                        fontSize: 12,
                        color: Colors.white.withValues(alpha: 0.6),
                        height: 1.6,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// 5. ORBITAL SCORE SECTION — radial ring + 5 metric labels around it
// ═══════════════════════════════════════════════════════════════════════════════

class _OrbitalScoreSection extends StatelessWidget {
  final ElenaTodayState state;
  const _OrbitalScoreSection({required this.state});

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final areaSize = (screenWidth - 40).clamp(280.0, 400.0);
    final ringSize = areaSize * 0.55;

    // Format display values
    final hydrationStr =
        '${state.hydrationLiters.toStringAsFixed(1)}L / ${state.hydrationGoalLiters.toStringAsFixed(1)}L';
    final exerciseStr = '${state.exerciseActiveMinutes}M ACTIVOS';
    final nutritionStr =
        '${state.nutritionKcal.toStringAsFixed(0)} KCAL';

    final sleepH = state.sleepHours.floor();
    final sleepM = ((state.sleepHours - sleepH) * 60).round();
    final sleepStr = '${sleepH}H ${sleepM}M';

    // Feeding window info
    final windowStr = state.fastingWindow.state == 'fasting'
        ? 'ABRE EN ${state.fastingWindow.nextMilestone.inHours}:${(state.fastingWindow.nextMilestone.inMinutes % 60).toString().padLeft(2, '0')}H'
        : 'CIERRA EN ${state.fastingWindow.nextMilestone.inHours}:${(state.fastingWindow.nextMilestone.inMinutes % 60).toString().padLeft(2, '0')}H';

    final targetProgress = (state.score.score / 100).clamp(0.0, 1.0);

    return SizedBox(
      width: areaSize,
      height: areaSize,
      child: Stack(
        alignment: Alignment.center,
        children: [
          // Central ring — animated arc via TweenAnimationBuilder
          TweenAnimationBuilder<double>(
            tween: Tween<double>(begin: 0.0, end: targetProgress),
            duration: const Duration(milliseconds: 1200),
            curve: Curves.easeOutCubic,
            builder: (context, animatedProgress, _) {
              return CustomPaint(
                size: Size(ringSize, ringSize),
                painter: _ScoreRingPainter(
                  progress: animatedProgress,
                  trackColor: Colors.white.withValues(alpha: 0.05),
                  progressColor: AppTheme.primary,
                  strokeWidth: 8,
                ),
              );
            },
          ),
          // Centre text
          Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'IED SCORE',
                style: GoogleFonts.jetBrainsMono(
                  fontSize: 11,
                  color: Colors.white.withValues(alpha: 0.4),
                  letterSpacing: 3,
                ),
              ),
              TweenAnimationBuilder<double>(
                tween: Tween<double>(begin: 0, end: state.score.score),
                duration: const Duration(milliseconds: 1200),
                curve: Curves.easeOutCubic,
                builder: (context, animatedScore, _) {
                  return Text(
                    animatedScore.toStringAsFixed(0),
                    style: GoogleFonts.outfit(
                      fontSize: 64,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                      height: 1.1,
                    ),
                  );
                },
              ),
              Text(
                state.score.label.toUpperCase(),
                style: GoogleFonts.jetBrainsMono(
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                  color: _labelColor(state.score.score),
                  letterSpacing: 2,
                ),
              ),
            ],
          ),
          // ── ORBITAL LABELS (5 metrics around the ring) ──────────────
          // Top center: Hidratación
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: Center(
              child: _OrbitalMetric(
                icon: Icons.water_drop_rounded,
                label: 'HIDRATACIÓN',
                value: hydrationStr,
                color: Colors.cyanAccent,
              ),
            ),
          ),
          // Left: Ejercicio
          Positioned(
            left: 0,
            top: areaSize * 0.45,
            child: _OrbitalMetric(
              icon: Icons.local_fire_department_rounded,
              label: 'EJERCICIO',
              value: exerciseStr,
              color: Colors.redAccent,
              alignment: CrossAxisAlignment.start,
            ),
          ),
          // Right: Nutrición
          Positioned(
            right: 0,
            top: areaSize * 0.45,
            child: _OrbitalMetric(
              icon: Icons.restaurant_rounded,
              label: 'NUTRICIÓN',
              value: nutritionStr,
              color: Colors.orangeAccent,
              alignment: CrossAxisAlignment.end,
            ),
          ),
          // Bottom left: Vent. Alim.
          Positioned(
            left: areaSize * 0.02,
            bottom: 0,
            child: _OrbitalMetric(
              icon: Icons.timer_rounded,
              label: 'VENT. ALIM.',
              value: windowStr,
              color: AppTheme.primary,
              alignment: CrossAxisAlignment.start,
            ),
          ),
          // Bottom right: Sueño
          Positioned(
            right: areaSize * 0.02,
            bottom: 0,
            child: _OrbitalMetric(
              icon: Icons.nightlight_round,
              label: 'SUEÑO',
              value: sleepStr,
              color: Colors.white.withValues(alpha: 0.7),
              alignment: CrossAxisAlignment.end,
            ),
          ),
        ],
      ),
    );
  }

  static Color _labelColor(double score) {
    if (score >= 80) return AppTheme.primary;
    if (score >= 60) return Colors.orangeAccent;
    return Colors.redAccent;
  }
}

class _OrbitalMetric extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;
  final Color color;
  final CrossAxisAlignment alignment;

  const _OrbitalMetric({
    required this.icon,
    required this.label,
    required this.value,
    required this.color,
    this.alignment = CrossAxisAlignment.center,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: alignment,
      children: [
        Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: color, size: 14),
            const SizedBox(width: 4),
            Text(
              label,
              style: GoogleFonts.jetBrainsMono(
                fontSize: 9,
                fontWeight: FontWeight.bold,
                color: Colors.white.withValues(alpha: 0.5),
                letterSpacing: 1,
              ),
            ),
          ],
        ),
        const SizedBox(height: 2),
        Text(
          value,
          style: GoogleFonts.jetBrainsMono(
            fontSize: 11,
            fontWeight: FontWeight.bold,
            color: color,
          ),
        ),
      ],
    );
  }
}

class _ScoreRingPainter extends CustomPainter {
  final double progress;
  final Color trackColor;
  final Color progressColor;
  final double strokeWidth;

  _ScoreRingPainter({
    required this.progress,
    required this.trackColor,
    required this.progressColor,
    this.strokeWidth = 10.0,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = (size.width / 2) - strokeWidth;
    const startAngle = -math.pi / 2;
    final sweepAngle = 2 * math.pi * progress;

    // Outer glow
    canvas.drawCircle(
      center,
      radius + 2,
      Paint()
        ..color = progressColor.withValues(alpha: 0.08)
        ..style = PaintingStyle.stroke
        ..strokeWidth = strokeWidth + 6
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 8),
    );

    // Track
    canvas.drawCircle(
      center,
      radius,
      Paint()
        ..color = trackColor
        ..style = PaintingStyle.stroke
        ..strokeWidth = strokeWidth,
    );

    // Progress arc
    canvas.drawArc(
      Rect.fromCircle(center: center, radius: radius),
      startAngle,
      sweepAngle,
      false,
      Paint()
        ..color = progressColor
        ..style = PaintingStyle.stroke
        ..strokeWidth = strokeWidth
        ..strokeCap = StrokeCap.round,
    );

    // Tick marks at 25% intervals
    for (int i = 0; i < 4; i++) {
      final tickAngle = startAngle + (2 * math.pi * i / 4);
      final innerR = radius - strokeWidth / 2 - 2;
      final outerR = radius + strokeWidth / 2 + 2;
      canvas.drawLine(
        Offset(
          center.dx + innerR * math.cos(tickAngle),
          center.dy + innerR * math.sin(tickAngle),
        ),
        Offset(
          center.dx + outerR * math.cos(tickAngle),
          center.dy + outerR * math.sin(tickAngle),
        ),
        Paint()
          ..color = Colors.white.withValues(alpha: 0.1)
          ..strokeWidth = 1,
      );
    }
  }

  @override
  bool shouldRepaint(covariant _ScoreRingPainter oldDelegate) =>
      oldDelegate.progress != progress;
}

// ═══════════════════════════════════════════════════════════════════════════════
// 6. HUNGER PANIC CARD — amber outlined → opens BottomSheet + writes Firestore
// ═══════════════════════════════════════════════════════════════════════════════

class _HungerPanicCard extends StatelessWidget {
  final WidgetRef ref;
  const _HungerPanicCard({required this.ref});

  static const _amber = Color(0xFFBF8B2E);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        HapticFeedback.heavyImpact();
        _showPanicSheet(context);
      },
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 18),
        decoration: BoxDecoration(
          color: Colors.transparent,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: _amber.withValues(alpha: 0.5), width: 1),
        ),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'PÁNICO DE HAMBRE',
                    style: GoogleFonts.jetBrainsMono(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: _amber,
                      letterSpacing: 2,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'REGISTRA CÓMO TE SIENTES AHORA',
                    style: GoogleFonts.jetBrainsMono(
                      fontSize: 10,
                      color: Colors.white.withValues(alpha: 0.4),
                      letterSpacing: 1,
                    ),
                  ),
                ],
              ),
            ),
            const Icon(Icons.warning_amber_rounded, color: _amber, size: 32),
          ],
        ),
      ),
    );
  }

  void _showPanicSheet(BuildContext context) {
    final fastingAsync = ref.read(fastingControllerProvider);
    final fasting = fastingAsync.valueOrNull;
    final isFasting = fasting?.isFasting ?? false;
    final elapsed = fasting?.elapsed ?? Duration.zero;

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => _PanicBottomSheet(
        ref: ref,
        isFasting: isFasting,
        fastingElapsed: elapsed,
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// PANIC BOTTOM SHEET — hunger level slider + Firestore write
// ═══════════════════════════════════════════════════════════════════════════════

class _PanicBottomSheet extends StatefulWidget {
  final WidgetRef ref;
  final bool isFasting;
  final Duration fastingElapsed;

  const _PanicBottomSheet({
    required this.ref,
    required this.isFasting,
    required this.fastingElapsed,
  });

  @override
  State<_PanicBottomSheet> createState() => _PanicBottomSheetState();
}

class _PanicBottomSheetState extends State<_PanicBottomSheet> {
  static const _amber = Color(0xFFBF8B2E);
  double _hungerLevel = 5;
  bool _isSaving = false;
  bool _saved = false;

  @override
  Widget build(BuildContext context) {
    final advice = widget.isFasting
        ? 'Estás en ayuno activo. Bebe 250 ml de agua con una pizca de sal y espera 15 minutos. '
            'Si persiste, considera romper el ayuno de forma controlada.'
        : 'Estás en ventana de alimentación. Elige una comida rica en proteína y grasa '
            'saludable para estabilizar la glucosa.';

    final stateLabel = widget.isFasting ? 'AYUNO ACTIVO' : 'VENTANA ALIMENTARIA';

    return Container(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom + 24,
      ),
      decoration: const BoxDecoration(
        color: Color(0xFF0A0A0A),
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        border: Border(
          top: BorderSide(color: _amber, width: 1),
          left: BorderSide(color: _amber, width: 0.5),
          right: BorderSide(color: _amber, width: 0.5),
        ),
      ),
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 12),
              // Handle bar
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: Colors.white.withValues(alpha: 0.2),
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 24),
              // Title
              Row(
                children: [
                  const Icon(Icons.warning_amber_rounded,
                      color: _amber, size: 22),
                  const SizedBox(width: 10),
                  Text(
                    'PROTOCOLO HAMBRE',
                    style: GoogleFonts.jetBrainsMono(
                      color: _amber,
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                      letterSpacing: 2,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              // Context label
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  border: Border.all(
                    color: widget.isFasting
                        ? Colors.orangeAccent.withValues(alpha: 0.4)
                        : AppTheme.primary.withValues(alpha: 0.4),
                    width: 1,
                  ),
                  borderRadius: BorderRadius.circular(4),
                ),
                child: Text(
                  stateLabel,
                  style: GoogleFonts.jetBrainsMono(
                    fontSize: 9,
                    fontWeight: FontWeight.bold,
                    color: widget.isFasting
                        ? Colors.orangeAccent
                        : AppTheme.primary,
                    letterSpacing: 1,
                  ),
                ),
              ),
              const SizedBox(height: 20),
              // Hunger level slider
              Text(
                'NIVEL DE HAMBRE',
                style: GoogleFonts.jetBrainsMono(
                  fontSize: 10,
                  color: Colors.white.withValues(alpha: 0.5),
                  letterSpacing: 2,
                ),
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  Text(
                    _hungerLevel.toStringAsFixed(0),
                    style: GoogleFonts.outfit(
                      fontSize: 36,
                      fontWeight: FontWeight.bold,
                      color: _hungerColor,
                    ),
                  ),
                  Text(
                    ' /10',
                    style: GoogleFonts.jetBrainsMono(
                      fontSize: 14,
                      color: Colors.white.withValues(alpha: 0.3),
                    ),
                  ),
                  const Spacer(),
                  Text(
                    _hungerDescription,
                    style: GoogleFonts.jetBrainsMono(
                      fontSize: 10,
                      color: _hungerColor,
                      letterSpacing: 1,
                    ),
                  ),
                ],
              ),
              SliderTheme(
                data: SliderThemeData(
                  activeTrackColor: _hungerColor,
                  inactiveTrackColor: Colors.white.withValues(alpha: 0.08),
                  thumbColor: _hungerColor,
                  overlayColor: _hungerColor.withValues(alpha: 0.15),
                  trackHeight: 4,
                  thumbShape:
                      const RoundSliderThumbShape(enabledThumbRadius: 8),
                ),
                child: Slider(
                  value: _hungerLevel,
                  min: 1,
                  max: 10,
                  divisions: 9,
                  onChanged: (v) {
                    HapticFeedback.selectionClick();
                    setState(() => _hungerLevel = v);
                  },
                ),
              ),
              const SizedBox(height: 16),
              // Advice
              Text(
                advice,
                style: GoogleFonts.publicSans(
                  color: Colors.white.withValues(alpha: 0.7),
                  fontSize: 13,
                  height: 1.6,
                ),
              ),
              const SizedBox(height: 24),
              // Action button
              SizedBox(
                width: double.infinity,
                height: 48,
                child: _saved
                    ? _buildConfirmation()
                    : ElevatedButton(
                        onPressed: _isSaving ? null : _handleSave,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: _amber.withValues(alpha: 0.15),
                          foregroundColor: _amber,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8),
                            side: BorderSide(
                                color: _amber.withValues(alpha: 0.5)),
                          ),
                          elevation: 0,
                        ),
                        child: _isSaving
                            ? SizedBox(
                                width: 18,
                                height: 18,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  color: _amber,
                                ),
                              )
                            : Text(
                                'REGISTRAR EVENTO',
                                style: GoogleFonts.jetBrainsMono(
                                  fontSize: 13,
                                  fontWeight: FontWeight.bold,
                                  letterSpacing: 2,
                                ),
                              ),
                      ),
              ),
              const SizedBox(height: 8),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildConfirmation() {
    return Container(
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: AppTheme.primary.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(8),
        border:
            Border.all(color: AppTheme.primary.withValues(alpha: 0.3)),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.check_circle_outline,
              color: AppTheme.primary, size: 18),
          const SizedBox(width: 8),
          Text(
            'EVENTO REGISTRADO',
            style: GoogleFonts.jetBrainsMono(
              fontSize: 12,
              fontWeight: FontWeight.bold,
              color: AppTheme.primary,
              letterSpacing: 1,
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _handleSave() async {
    setState(() => _isSaving = true);
    try {
      final repo = widget.ref.read(telemetryRepositoryProvider);
      
      // Get user data from stream
      final user = widget.ref.read(currentUserStreamProvider).valueOrNull;
      if (user?.uid == null) {
        setState(() => _isSaving = false);
        return;
      }

      await repo.writePanicLog(
        uid: user!.uid,
        hungerLevel: _hungerLevel.round(),
        context: widget.isFasting ? 'fasting' : 'feeding',
        wasFasting: widget.isFasting,
        fastingElapsed: widget.fastingElapsed,
      );

      if (mounted) {
        HapticFeedback.mediumImpact();
        setState(() {
          _isSaving = false;
          _saved = true;
        });
        // Auto-dismiss after delay
        Future.delayed(const Duration(seconds: 2), () {
          if (mounted) Navigator.of(context).pop();
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() => _isSaving = false);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'Error registrando evento: $e',
              style: GoogleFonts.jetBrainsMono(fontSize: 11),
            ),
            backgroundColor: Colors.redAccent,
          ),
        );
      }
    }
  }

  Color get _hungerColor {
    if (_hungerLevel <= 3) return AppTheme.primary;
    if (_hungerLevel <= 6) return const Color(0xFFBF8B2E);
    return Colors.redAccent;
  }

  String get _hungerDescription {
    if (_hungerLevel <= 2) return 'LEVE';
    if (_hungerLevel <= 4) return 'MODERADO';
    if (_hungerLevel <= 6) return 'CONSIDERABLE';
    if (_hungerLevel <= 8) return 'INTENSO';
    return 'EXTREMO';
  }
}
